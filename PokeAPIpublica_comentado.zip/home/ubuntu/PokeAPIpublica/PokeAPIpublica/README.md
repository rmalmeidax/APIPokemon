# PokeAPI Pública

Este projeto é uma aplicação Spring Boot que interage com a PokeAPI (https://pokeapi.co/) para buscar informações de Pokémons e também permite o gerenciamento (CRUD) de Pokémons em um banco de dados local.

## Estrutura do Projeto

O projeto segue a estrutura padrão de uma aplicação Spring Boot, organizada em pacotes que representam as diferentes camadas da aplicação:

- `com.example.pokeapipublica.DTO`: Contém os Data Transfer Objects (DTOs) para a comunicação entre as camadas e com a API externa.
- `com.example.pokeapipublica.config`: Classes de configuração da aplicação.
- `com.example.pokeapipublica.controller`: Controladores REST que expõem os endpoints da API.
- `com.example.pokeapipublica.entity`: Entidades JPA que representam as tabelas do banco de dados.
- `com.example.pokeapipublica.repository`: Interfaces de repositório para acesso aos dados, utilizando Spring Data JPA.
- `com.example.pokeapipublica.service`: Camada de serviço que contém a lógica de negócios da aplicação.

## Tecnologias Utilizadas

- **Java 17**
- **Spring Boot**: Framework para construção de aplicações Java.
- **Spring Data JPA**: Para persistência de dados e interação com o banco de dados.
- **Lombok**: Para reduzir o código boilerplate (getters, setters, construtores, etc.).
- **Maven**: Ferramenta de automação de build e gerenciamento de dependências.
- **H2 Database**: Banco de dados em memória para desenvolvimento e testes (configurável).
- **RestTemplate**: Para consumir a PokeAPI externa.

## Como Rodar o Projeto

1.  **Pré-requisitos**:
    *   Java Development Kit (JDK) 17 ou superior instalado.
    *   Maven instalado.

2.  **Clonar o repositório**:

    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd PokeAPIpublica
    ```

3.  **Compilar e Rodar**:

    Você pode compilar e rodar a aplicação usando Maven:

    ```bash
    mvn clean install
    mvn spring-boot:run
    ```

    A aplicação estará disponível em `http://localhost:8080`.

## Endpoints da API

Os seguintes endpoints estão disponíveis:

### Pokémons Locais (CRUD)

-   **GET /pokemon**
    *   Retorna todos os Pokémons cadastrados no banco de dados local.

-   **GET /pokemon/{id}**
    *   Retorna um Pokémon específico pelo seu ID.
    *   Exemplo: `GET /pokemon/1`

-   **POST /pokemon**
    *   Cria um novo Pokémon no banco de dados local.
    *   **Corpo da Requisição (JSON)**:
        ```json
        {
            "nome": "Pikachu",
            "tipo": "Elétrico",
            "habilidade": "Estática"
        }
        ```

-   **DELETE /pokemon/{id}**
    *   Exclui um Pokémon do banco de dados local pelo seu ID.
    *   Exemplo: `DELETE /pokemon/1`

### Busca na PokeAPI Externa

-   **GET /pokemon/external/{nome}**
    *   Busca informações de um Pokémon na PokeAPI externa pelo seu nome.
    *   Retorna dados como nome, altura, peso e tipos.
    *   Exemplo: `GET /pokemon/external/pikachu`

## Comentários no Código

Todos os arquivos `.java` foram extensivamente comentados para facilitar a compreensão do código, explicando a finalidade de classes, métodos, atributos e anotações Spring/JPA/Lombok.

## Contribuição

Sinta-se à vontade para contribuir com este projeto. Para isso, siga os passos:

1.  Faça um fork do repositório.
2.  Crie uma nova branch (`git checkout -b feature/sua-feature`).
3.  Faça suas alterações e commit (`git commit -m 'Adiciona nova feature'`).
4.  Envie para a branch original (`git push origin feature/sua-feature`).
5.  Abra um Pull Request.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.


